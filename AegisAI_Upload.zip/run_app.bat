@echo off
cd /d "%~dp0"
echo Starting AegisAI Streamlit and API Services...
echo Make sure you have Ollama running locally!

start "AegisAI API" cmd /c "cd /d \"%~dp0\" && call venv\Scripts\activate.bat && uvicorn api:app --reload --port 8000"
start "AegisAI App" cmd /c "cd /d \"%~dp0\" && call venv\Scripts\activate.bat && streamlit run app.py"

echo Services started in separate windows!
pause
