import os
from langchain_community.document_loaders import PyMuPDFLoader, TextLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_ollama import OllamaEmbeddings
from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq
from core.config import config

class RAGPipeline:
    def __init__(self, db_path="data/chroma", model_name="llama3"):
        # Default: fast local embeddings (sentence-transformers). No Ollama needed for ingest.
        if config.USE_OLLAMA_EMBEDDINGS:
            self.embedding_model = OllamaEmbeddings(model="nomic-embed-text")
            self.db_path = db_path
        else:
            self.embedding_model = HuggingFaceEmbeddings(
                model_name=config.EMBEDDING_MODEL,
                model_kwargs={"device": "cpu"},
                encode_kwargs={"normalize_embeddings": True},
            )
            # Use a separate Chroma folder for 384-dim embeddings so we never open old 768-dim (Ollama) collections
            base = db_path.rstrip("/\\")
            self.db_path = base + "_sentence"
        
        # Hybrid Intelligence Switch
        if config.CLOUD_DEPLOYMENT and config.GROQ_API_KEY:
            # Use Groq for lightning fast cloud inference (e.g. llama3-70b-8192)
            self.llm = ChatGroq(
                groq_api_key=config.GROQ_API_KEY,
                model_name="llama3-70b-8192"
            )
        else:
            # Fallback to local Ollama
            self.llm = OllamaLLM(model=model_name)
            
        self.db = None

    def _load_documents(self, file_path: str, filename: str):
        """Load documents from a file using the appropriate loader by extension."""
        ext = os.path.splitext(file_path)[1].lower()
        if ext == ".pdf":
            loader = PyMuPDFLoader(file_path)
        elif ext in (".txt", ".text", ".md", ".markdown"):
            loader = TextLoader(file_path, encoding="utf-8", autodetect_encoding=True)
        elif ext in (".docx", ".doc"):
            loader = Docx2txtLoader(file_path)
        else:
            raise ValueError(f"Unsupported file type: {ext}. Use PDF, TXT, MD, or DOCX.")
        documents = loader.load()
        return documents

    def ingest_document(self, file_path: str, filename: str = None, progress_callback=None):
        """Ingest any supported document (PDF, TXT, MD, DOCX). The uploaded file is the input source for the AI."""
        display_name = filename or os.path.basename(file_path)
        documents = self._load_documents(file_path, display_name)
        if not documents:
            raise ValueError("No text could be extracted from this file. It may be empty or in an unsupported format.")

        for doc in documents:
            doc.metadata["source_name"] = display_name
            
        # FILTER: Ensure document isn't just empty objects
        documents = [d for d in documents if d.page_content.strip()]
        if not documents:
            raise ValueError(
                "No text could be extracted from this document using local tools. "
                "This often happens with scanned PDF images or password-protected files. "
                "Try converting it to a plain text or .docx file first."
            )

        # Reduced chunk size for significantly faster embedding/retrieval
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1500,
            chunk_overlap=150,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        docs = text_splitter.split_documents(documents)
        if not docs:
            # Fallback if text is very sparse but exists
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
            docs = text_splitter.split_documents(documents)
            
        if not docs:
            raise ValueError(
                "AegisAI detected the document is too sparse to index effectively. "
                "Ensure it contains actual searchable text, not just images."
            )

        if not self.db and os.path.exists(self.db_path):
            self.db = Chroma(persist_directory=self.db_path, embedding_function=self.embedding_model)

        # Optimal batching: Local embeddings (HuggingFace) are much faster in larger batches.
        batch_size = 32 if config.USE_OLLAMA_EMBEDDINGS else 128
        for i in range(0, len(docs), batch_size):
            batch = docs[i:i + batch_size]
            if not self.db:
                self.db = Chroma.from_documents(batch, self.embedding_model, persist_directory=self.db_path)
            else:
                self.db.add_documents(batch)
            if progress_callback:
                # Update progress based on chunks processed
                progress_callback(min(1.0, (i + len(batch)) / len(docs)))
        return docs

    def ingest_pdf(self, pdf_path, filename=None, progress_callback=None):
        """Convenience wrapper: ingest a PDF (use ingest_document for any file type)."""
        return self.ingest_document(pdf_path, filename=filename, progress_callback=progress_callback)

    def list_documents(self):
        """Returns a list of unique source names in the repository."""
        if not self.db:
            if os.path.exists(self.db_path):
                self.db = Chroma(persist_directory=self.db_path, embedding_function=self.embedding_model)
            else:
                return []
        
        data = self.db.get()
        if not data or not data["metadatas"]:
            return []
        sources = {m.get("source_name", "Unknown File") for m in data["metadatas"]}
        return list(sources)

    def delete_document(self, source_name):
        """Removes all chunks associated with a specific source name."""
        if not self.db:
            return False
        
        # Chroma doesn't have a direct 'delete by metadata' in all versions easily, 
        # so we get IDs first
        data = self.db.get(where={"source_name": source_name})
        ids_to_delete = data["ids"]
        
        if ids_to_delete:
            self.db.delete(ids=ids_to_delete)
            return True
        return False

    def get_repository_stats(self):
        """Returns stats about the vector store."""
        if not self.db:
            return {"total_chunks": 0, "total_docs": 0}
        data = self.db.get()
        total_chunks = len(data["ids"])
        sources = {m.get("source_name", "Unknown File") for m in data["metadatas"]}
        return {
            "total_chunks": total_chunks,
            "total_docs": len(sources)
        }

    def get_retriever(self, search_type="mmr"):
        if not self.db:
            if os.path.exists(self.db_path):
                self.db = Chroma(
                    persist_directory=self.db_path, 
                    embedding_function=self.embedding_model
                )
            else:
                return None
        return self.db.as_retriever(
            search_type=search_type,
            search_kwargs={"k": 3, "fetch_k": 6}  # smaller fetch_k = faster retrieval
        )

    def get_full_context(self, max_tokens=8000):
        """Fetches a high-density summary context to prevent context window overflows."""
        if not self.db:
            return ""
        all_docs = self.db.get()
        docs = all_docs['documents']
        
        # If the document is massive, we can't send it all. We take a representative sample.
        if len(docs) > 20: 
            # Strategy: First 10 chunks + Last 10 chunks (Start/End context is often most important)
            selected = docs[:10] + docs[-10:]
            return "\n\n[... Omitted middle section for performance ...]\n\n".join(selected)
        
        return "\n\n".join(docs)

    def route_query(self, query):
        """Routes query to either 'Broad' or 'Specific' processing."""
        broad_keywords = ["summarize", "all", "everything", "overview", "entire", "full", "whole", "explain the document"]
        if any(word in query.lower() for word in broad_keywords):
            return "Broad"
        return "Specific"

    def generate_answer(self, query, context, mode="Specific", learning_context="", stream=False):
        if mode == "Broad":
            role_prompt = "You are a senior analyst providing a comprehensive executive summary."
            instruction = "Analyze the entire document and explain its content in detail, covering all key sections."
        else:
            role_prompt = "You are a precise technical assistant."
            instruction = "Answer the question using only the provided context. If the answer is not in the context, say: 'The document does not mention this.'"
            
        prompt = f"""
        {learning_context}
        
        {role_prompt}
        
        {instruction}

        Context:
        {context}

        Question:
        {query}
        
        Detailed Response:
        """
        if stream:
            return self.llm.stream(prompt)
        return self.llm.invoke(prompt)
