import logging
import sys
from core.config import config

def setup_logging():
    logging.basicConfig(
        level=config.LOG_LEVEL,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("data/aegis_ai.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger("AegisAI")

logger = setup_logging()
