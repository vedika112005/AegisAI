import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    MODEL_NAME = os.getenv("MODEL_NAME", "mistral:latest")
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///database/audit.db")
    CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", "data/chroma")
    RISK_THRESHOLD = float(os.getenv("RISK_THRESHOLD", 0.70))
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    # Cloud Deployment Settings
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
    CLOUD_DEPLOYMENT = os.getenv("CLOUD_DEPLOYMENT", "false").lower() == "true"

    # Defaulting to false for significantly faster local embeddings (no Ollama API calls).
    USE_OLLAMA_EMBEDDINGS = os.getenv("USE_OLLAMA_EMBEDDINGS", "false").lower() == "true"

config = Config()
