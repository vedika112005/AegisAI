import json
from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq
from core.config import config

class ClaimEngine:
    def __init__(self, model_name="llama3"):
        if config.CLOUD_DEPLOYMENT and config.GROQ_API_KEY:
            self.llm = ChatGroq(groq_api_key=config.GROQ_API_KEY, model_name="llama3-70b-8192")
        else:
            self.llm = OllamaLLM(model=model_name)

    def decompose_claims(self, answer: str):
        prompt = f"""
        Break the following answer into atomic factual claims. 
        Each claim should be a standalone sentence that can be verified.
        Return as a JSON list of strings.
        
        Answer:
        {answer}
        """
        response = self.llm.invoke(prompt)
        try:
            json_str = response.strip()
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0].strip()
            elif "```" in json_str:
                 json_str = json_str.split("```")[1].split("```")[0].strip()
            
            claims = json.loads(json_str)
            if isinstance(claims, list):
                return claims
            return []
        except Exception:
            # Fallback to line splitting if JSON fails
            return [line.strip() for line in response.split("\n") if line.strip() and len(line) > 10]
        
