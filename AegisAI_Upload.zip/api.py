from fastapi import FastAPI, HTTPException, Request, Security, Depends
from fastapi.security.api_key import APIKeyHeader
from pydantic import BaseModel
from typing import List, Optional
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import time
import os

from core.risk_classifier import RiskClassifier
from core.rag_pipeline import RAGPipeline
from core.claim_engine import ClaimEngine
from core.verification import VerificationEngine
from core.scoring import ScoringEngine
from core.regeneration import RegenerationEngine
from database.audit_ledger import AuditLedger
from core.config import config
from core.logger import logger

app = FastAPI(title="AegisAI Enterprise API", version="1.1.0")

# CORS Configuration for external frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
API_KEY_NAME = "X-Aegis-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

async def get_api_key(api_key: str = Depends(api_key_header)):
    expected_key = os.getenv("API_KEY", "aegis_secure_123")
    if api_key == expected_key:
        return api_key
    raise HTTPException(status_code=403, detail="Unauthorized: Invalid Aegis API Key")

# Schemas
class QueryRequest(BaseModel):
    query: str
    department: str = "General"
    strict_mode: bool = False

class VerificationResponse(BaseModel):
    id: str
    query: str
    answer: str
    grounding_score: float
    risk_level: str
    claims: List[str]
    verifications: List[dict]

# Initialize components
logger.info("Initializing AegisAI components...")
classifier = RiskClassifier(model_name=config.MODEL_NAME)
rag = RAGPipeline(db_path=config.CHROMA_DB_PATH, model_name=config.MODEL_NAME)
claims_engine = ClaimEngine(model_name=config.MODEL_NAME)
verification_engine = VerificationEngine(rag.embedding_model, model_name=config.MODEL_NAME)
scoring_engine = ScoringEngine()
regen_engine = RegenerationEngine(model_name=config.MODEL_NAME)
ledger = AuditLedger(db_url=config.DATABASE_URL)

@app.get("/health")
def health_check():
    return {"status": "healthy", "timestamp": time.time()}

@app.post("/verify", response_model=VerificationResponse, dependencies=[Depends(get_api_key)])
async def verify_query(request: QueryRequest):
    logger.info(f"Incoming request for department: {request.department}")
    start_time = time.time()
    
    try:
        # 1. Classify
        risk_meta = classifier.classify_query(request.query)
        logger.info(f"Query classified as {risk_meta['category']} with {risk_meta['risk_level']} risk")
        
        # 2. Retrieve & Generate
        retriever = rag.get_retriever()
        if not retriever:
            logger.error("Attempted verification without knowledge base indexing.")
            raise HTTPException(status_code=400, detail="Knowledge base not initialized.")
        
        relevant_docs = retriever.invoke(request.query)
        context = "\n\n".join([d.page_content for d in relevant_docs])
        answer = rag.generate_answer(request.query, context)
        
        # 3. Parallel Verification (Significant speedup)
        import concurrent.futures
        decomposed_claims = claims_engine.decompose_claims(answer)
        verifications = []
        
        def process_api_claim(claim):
             return verification_engine.verify_claim(claim, [d.page_content for d in relevant_docs])

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            future_to_claim = {executor.submit(process_api_claim, c): c for c in decomposed_claims}
            for future in concurrent.futures.as_completed(future_to_claim):
                verifications.append(future.result())
        
        # 4. Score
        scores = scoring_engine.calculate_scores(verifications, risk_meta['risk_level'])
        
        # 5. Adaptive Regen if needed
        final_answer = answer
        if scores['safety_percentage'] < (config.RISK_THRESHOLD * 100):
            logger.warning(f"Low grounding score ({scores['safety_percentage']}%). Triggering regeneration.")
            unsupported = [v['claim'] for v in verifications if v['verdict'] in ["Unsupported", "Possibly Unsupported"]]
            final_answer = regen_engine.regenerate(request.query, answer, unsupported, context)
        
        # 6. Audit
        ledger_data = {
            "query": request.query,
            "category": risk_meta['category'],
            "risk_level": risk_meta['risk_level'],
            "answer": final_answer,
            "claims": decomposed_claims,
            "verifications": verifications,
            "grounding_score": scores['grounding_score'],
            "risk_score": scores['hallucination_risk'],
            "final_risk_class": scores['risk_class'],
            "department": request.department
        }
        ledger.log_interaction(ledger_data)
        
        process_time = time.time() - start_time
        logger.info(f"Verification complete in {process_time:.2f}s")
        
        return {
            "id": str(int(time.time())),
            "query": request.query,
            "answer": final_answer,
            "grounding_score": scores['grounding_score'],
            "risk_level": scores['risk_class'],
            "claims": decomposed_claims,
            "verifications": verifications
        }
    except Exception as e:
        logger.error(f"Error during verification: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
