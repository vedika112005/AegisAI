class RiskBudgetEnforcement:
    def __init__(self, budgets=None):
        # Default budgets: Max percentage of High/Critical risk responses allowed
        self.budgets = budgets or {
            "Finance": 0.05,
            "Healthcare": 0.02,
            "Legal": 0.05,
            "HR": 0.10,
            "General": 0.15,
            "Marketing": 0.20
        }

    def check_budget(self, department, recent_interactions):
        if not recent_interactions:
            return True, 0.0
            
        dept_interactions = [i for i in recent_interactions if i.department == department]
        if not dept_interactions:
            return True, 0.0
            
        high_risk_count = len([i for i in dept_interactions if i.final_risk_class in ["High Risk", "Critical"]])
        current_rate = high_risk_count / len(dept_interactions)
        
        allowed_rate = self.budgets.get(department, 0.15)
        
        if current_rate > allowed_rate:
            return False, current_rate
        return True, current_rate
