import sqlite3
import os

db_path = "database/audit.db"

if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Check if columns already exist
        cursor.execute("PRAGMA table_info(interactions)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if "user_rating" not in columns:
            print("Adding user_rating column...")
            cursor.execute("ALTER TABLE interactions ADD COLUMN user_rating INTEGER")
            
        if "user_feedback" not in columns:
            print("Adding user_feedback column...")
            cursor.execute("ALTER TABLE interactions ADD COLUMN user_feedback TEXT")
            
        conn.commit()
        print("Database migration successful!")
    except Exception as e:
        print(f"Error during migration: {e}")
    finally:
        conn.close()
else:
    print("Database file not found. Nothing to migrate.")
