import logging
from database.audit_ledger import AuditLedger

class SelfImprovementEngine:
    def __init__(self, ledger: AuditLedger):
        self.ledger = ledger
        self.logger = logging.getLogger("AegisAI")

    def get_learning_context(self):
        """Retrieves past successes to teach the model."""
        successes = self.ledger.get_highly_rated(limit=3)
        if not successes:
            return ""
        
        context = "### ORGANIZATIONAL KNOWLEDGE: PAST VERIFIED ANSWERS\n"
        context += "Use the following examples of high-quality, verified organizational responses to guide your tone and accuracy:\n\n"
        
        for item in successes:
            context += f"Query: {item.query}\n"
            context += f"Golden Answer (Verified): {item.answer}\n"
            context += "---\n"
        
        return context + "\n"
