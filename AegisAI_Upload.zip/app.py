import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
import json
from datetime import datetime

from core.config import config
from core.risk_classifier import RiskClassifier
from core.rag_pipeline import RAGPipeline
from core.claim_engine import ClaimEngine
from core.verification import VerificationEngine
from core.scoring import ScoringEngine
from core.regeneration import RegenerationEngine
from core.risk_budget import RiskBudgetEnforcement
from core.self_improvement import SelfImprovementEngine
from database.audit_ledger import AuditLedger

# Global Constants & Pipeline Archetype
STAGES = ["Classify", "Retrieve", "Decompose", "Verify", "Score", "Regen", "Audit"]
STAGES_INFO = {
    "Classify": "🛡️ **Query Intelligence**: Analyzes intent and identifies organizational risk categories (Legal, HR, Finance) before the AI even sees the prompt.",
    "Retrieve": "🔍 **Smart Context**: Fetches verified evidence from the Knowledge Library using semantic vector search and MMR (Maximal Marginal Relevance).",
    "Decompose": "🧩 **Atomic Extraction**: Breaks down complex AI responses into single, verifiable factual assertions for individual audit.",
    "Verify": "⚖️ **Logical Entailment**: Cross-references every claim against document evidence using semantic overlap and secondary critique models.",
    "Score": "📊 **Safety Quantization**: Calculates total grounding (%) and hallucination risk to decide if a response is safe for the organization.",
    "Regen": "🔄 **Policy-Enforced Rewriting**: Automatically filters and regenerates unsupported claims to prevent hallucinations from reaching the user.",
    "Audit": "📜 **Enterprise Ledger**: Cryptographically logs the entire reasoning path, grounding scores, and evidence for regulatory compliance."
}

# UI Configuration
st.set_page_config(
    page_title="AegisAI | Enterprise Governance",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Premium Enterprise Dark Mode
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap');

    :root {
        --primary: #6366f1; /* Indigo - Modern & Trustworthy */
        --primary-accent: #818cf8;
        --bg-main: #0f172a; /* Deep Navy/Slate - Premium Dark */
        --bg-card: rgba(30, 41, 59, 0.7); /* Glassy Slate */
        --border-color: rgba(226, 232, 240, 0.1);
        --text-header: #f8fafc;
        --text-body: #cbd5e1;
        --text-muted: #94a3b8;
    }

    [data-testid="stAppViewContainer"] {
        background-color: var(--bg-main);
        background-image: radial-gradient(circle at 2px 2px, rgba(255,255,255,0.05) 1px, transparent 0);
        background-size: 40px 40px;
        font-family: 'Inter', sans-serif;
        color: var(--text-body);
    }

    /* Muted Status Colors - High Contrast for Dark Mode */
    .supported { color: #34d399 !important; font-weight: 600; }
    .unsupported { color: #f87171 !important; font-weight: 600; }
    .partially { color: #fbbf24 !important; font-weight: 600; }

    /* Glassmorphism Card Styling */
    .stMetric, .risk-card {
        background: var(--bg-card) !important;
        backdrop-filter: blur(12px) !important;
        -webkit-backdrop-filter: blur(12px) !important;
        padding: 24px !important;
        border-radius: 12px !important;
        border: 1px solid var(--border-color) !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
        margin-bottom: 20px;
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    
    .risk-card:hover {
        border-color: rgba(99, 102, 241, 0.3) !important;
    }

    .risk-card {
        border-left: 4px solid var(--primary) !important;
    }

    /* Professional Sidebar Dark */
    [data-testid="stSidebar"] {
        background-color: #020617 !important;
        border-right: 1px solid var(--border-color);
    }

    /* Typography */
    h1, h2, h3 {
        font-family: 'IBM Plex Sans', sans-serif !important;
        font-weight: 600 !important;
        color: var(--text-header) !important;
        letter-spacing: -0.02em !important;
        margin-bottom: 1.2rem !important;
    }

    p, span, label, .stMarkdown {
        color: var(--text-body) !important;
    }

    /* Input Fields - Dark Mode Optimized */
    .stTextInput>div>div>input {
        background-color: #1e293b !important;
        color: #f8fafc !important;
        border-radius: 8px !important;
        border: 1px solid var(--border-color) !important;
        padding: 12px !important;
    }

    /* Button Styling - Vibrant Contrast */
    .stButton>button {
        background-color: var(--primary) !important;
        color: white !important;
        border-radius: 8px !important;
        border: none !important;
        padding: 0.6rem 1.5rem !important;
        font-weight: 600 !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        box-shadow: 0 4px 14px 0 rgba(99, 102, 241, 0.39) !important;
    }

    .stButton>button:hover {
        background-color: var(--primary-accent) !important;
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(99, 102, 241, 0.23) !important;
    }

    /* Streamlined Progress Stages */
    .stage-indicator {
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--text-muted);
        text-align: center;
        margin-bottom: 8px;
    }
    
    .active-stage {
        border-bottom: 3px solid var(--primary) !important;
        color: var(--text-header) !important;
    }

    /* Fix for file uploader text visibility */
    .stFileUploader section div {
        color: var(--text-muted) !important;
    }
    
    /* Metrics visibility */
    [data-testid="stMetricValue"] {
        color: var(--text-header) !important;
    }
    
    [data-testid="stMetricDelta"] {
        background-color: rgba(0,0,0,0) !important;
    }

    /* Divider visibility */
    hr {
        border-color: var(--border-color) !important;
    }

    /* Hide redundant Streamlit elements */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    
</style>
""", unsafe_allow_html=True)

# Initialize Backend Components
@st.cache_resource
def init_components():
    classifier = RiskClassifier(model_name=config.MODEL_NAME)
    rag = RAGPipeline(db_path=config.CHROMA_DB_PATH, model_name=config.MODEL_NAME)
    claims = ClaimEngine(model_name=config.MODEL_NAME)
    verification = VerificationEngine(rag.embedding_model, model_name=config.MODEL_NAME)
    scoring = ScoringEngine()
    regen = RegenerationEngine(model_name=config.MODEL_NAME)
    ledger = AuditLedger(db_url=config.DATABASE_URL)
    budget = RiskBudgetEnforcement()
    learner = SelfImprovementEngine(ledger)
    return classifier, rag, claims, verification, scoring, regen, ledger, budget, learner

classifier, rag, claims_engine, verification_engine, scoring_engine, regen_engine, ledger, budget_engine, learner_engine = init_components()


# UI Utilities
def render_header(icon_path, title, size=40):
    if os.path.exists(icon_path):
        with open(icon_path, "r") as f:
            svg_code = f.read()
        # Clean SVG for inline use
        svg_code = svg_code.replace('width="40"', f'width="{size}"').replace('height="40"', f'height="{size}"')
        st.markdown(f"""
        <div class="flex-container">
            <div>{svg_code}</div>
            <h1 style="margin:0;">{title}</h1>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.title(title)

# Initialize Dynamic Governance State
if 'risk_threshold' not in st.session_state:
    # Convert decimal threshold (0.7) to percentage (70) for UI
    st.session_state.risk_threshold = int(config.RISK_THRESHOLD * 100) if config.RISK_THRESHOLD <= 1.0 else int(config.RISK_THRESHOLD)
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'selected_docs' not in st.session_state:
    st.session_state.selected_docs = []

# Sidebar - Configuration & Navigation
with st.sidebar:
    st.markdown("### AegisAI Engine")
    
    app_mode = st.radio("System View", [
        "Risk Orchestrator", 
        "Dashboard & Analytics", 
        "Audit Ledger", 
        "Governance Policy Center",
        "User Feedback Loop"
    ])
    
    st.divider()
    st.markdown("#### Deployment Context")
    dept = st.selectbox("Organizational Unit", ["General", "Finance", "Healthcare", "Legal", "HR", "Marketing"])
    
    st.divider()
    st.markdown("#### System Integrity")
    st.code(f"Model: {config.MODEL_NAME}\nStatus: Operational\nGuardrails: Active", language="yaml")

# --- NAVIGATION: Dashboard & Analytics ---
if app_mode == "Risk Orchestrator":
    render_header("data/orchestrator_icon.svg", "AI Risk Orchestration", size=50)
    
    # Sub-header for Pipeline with better spacing
    st.markdown('<div style="margin-top: 25px;"></div>', unsafe_allow_html=True)
    if os.path.exists("data/pipeline_icon.svg"):
        with open("data/pipeline_icon.svg", "r") as f:
            svg_pipe = f.read()
        st.markdown(f"""
        <div class="flex-container" style="gap: 10px; margin-bottom: 10px;">
            <div style="width: 30px;">{svg_pipe.replace('width="40"','width="30"').replace('height="40"','height="30"')}</div>
            <h3 style="margin:0; font-size: 1.25rem; color: var(--text-muted);">Governance Pipeline Progress</h3>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.write("### Governance Pipeline Progress")
    
    cols = st.columns(len(STAGES))
    for i, s in enumerate(STAGES):
        cols[i].markdown(f"<div class='stage-indicator' style='text-align:center;'>Stage {i+1}</div>", unsafe_allow_html=True)
        if cols[i].button(s, key=f"btn_{s}", use_container_width=True):
            st.session_state.active_stage_info = s

    if 'active_stage_info' in st.session_state:
        st.info(STAGES_INFO[st.session_state.active_stage_info])
        if st.button("Close Explanation", key="close_stage_info"):
            del st.session_state.active_stage_info
            st.rerun()

    st.divider()

    # Knowledge Repository Manager
    with st.expander("📚 Enterprise Knowledge Library (CRUD)", expanded=True):
        stats = rag.get_repository_stats()
        c1, c2 = st.columns(2)
        c1.metric("Indexed Documents", stats['total_docs'])
        c2.metric("Neural Chunks", stats['total_chunks'])
        
        st.divider()
        
        existing_docs = rag.list_documents()
        if existing_docs:
            st.write("**Manage Source Documents:**")
            to_delete = []
            for d in existing_docs:
                col_a, col_b = st.columns([8, 2])
                col_a.markdown(f"📄 `{d}`")
                if col_b.button("🗑️ Delete", key=f"del_{d}", help="Permanently remove from organizational brain"):
                    rag.delete_document(d)
                    st.success(f"Purged {d}")
                    st.rerun()
        else:
            st.info("Your knowledge repository is empty. Upload a document to begin.")
            
        uploaded_file = st.file_uploader(
            "📂 Upload a document",
            type=["pdf", "txt", "md", "docx", "doc"],
            help="Upload any document (PDF, TXT, MD, or Word). The AI will use only this document as its source."
        )

        if uploaded_file:
            if uploaded_file.name in existing_docs:
                st.info(f"'{uploaded_file.name}' is already indexed and ready for queries.")
            else:
                # Save with original extension so the right loader is used
                ext = os.path.splitext(uploaded_file.name)[1].lower() or ".pdf"
                temp_path = os.path.join("data", f"temp{ext}")
                os.makedirs("data", exist_ok=True)
                with open(temp_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())

                # Visible ingestion progress so the app doesn't feel frozen
                info_placeholder = st.empty()
                progress_bar = st.progress(0)
                info_placeholder.info(
                    "🚀 AegisAI High-Performance Ingestion: Splitting and indexing document using optimized local embeddings. "
                    "The first run may briefly download the transformer model; subsequent uploads are nearly instant."
                )

                def _on_progress(p: float):
                    try:
                        progress_bar.progress(int(max(0, min(1.0, p)) * 100))
                    except Exception:
                        # Best-effort UI update; ignore rendering errors
                        pass

                try:
                    ingest_fn = getattr(rag, "ingest_document", None)
                    if ingest_fn is None:
                        if ext == ".pdf":
                            ingest_fn = rag.ingest_pdf
                        else:
                            st.error(
                                "Multi-format upload needs an app restart. Close the Streamlit window, "
                                "run **run_app.bat** again, then try uploading."
                            )
                            st.stop()

                    with st.spinner("Embedding and indexing document chunks..."):
                        ingest_fn(temp_path, filename=uploaded_file.name, progress_callback=_on_progress)

                    progress_bar.progress(100)
                    info_placeholder.success("Document ingested successfully. Refreshing view...")
                    st.rerun()
                except Exception as e:
                    info_placeholder.empty()
                    err_msg = str(e)
                    st.error(f"Ingestion failed: {err_msg}")
                    if "dimension" in err_msg.lower() or "shape" in err_msg.lower():
                        st.info("The index was built with a different embedding model. Delete all documents from the library above, then re-upload.")
                    st.stop()

    query = st.text_input("💬 Enterprise Query", placeholder="Enter your query to run through the 10-stage governance loop...", label_visibility="collapsed")

    if query:
        # 1. RISK CLASSIFICATION
        with st.status("Initializing Governance Pipeline...", expanded=False) as status:
            st.write("Checking query intent and risk category...")
            risk_meta = classifier.classify_query(query)
            st.write(f"Query assigned to: {risk_meta['category']} ({risk_meta['risk_level']} Sensitivity)")
            status.update(label=f"Governance Pipeline: {risk_meta['category']} Intelligence Active", state="running")
        
        # 2. CONTEXT RETRIEVAL
        retriever = rag.get_retriever()
        
        if not retriever:
            st.warning("Knowledge Base is empty. AegisAI bypass applied.")
            st.markdown("### Output")
            st.write_stream(classifier.llm.stream(query))
            st.stop()
            
        query_mode = rag.route_query(query)
        learning_context = learner_engine.get_learning_context()
        
        # 3. RESPONSE GENERATION (STREAMING)
        st.markdown("### Verified Interaction")
        ans_box = st.empty()
        full_answer = ""
        
        # We fetch context first
        if query_mode == "Broad":
            context = rag.get_full_context()
        else:
            relevant_docs = retriever.invoke(query)
            context = "\n\n".join([d.page_content for d in relevant_docs])

        # Actual Streaming
        for chunk in rag.generate_answer(query, context, mode=query_mode, learning_context=learning_context, stream=True):
            full_answer += chunk
            ans_box.markdown(f"""<div class='risk-card'>{full_answer}▌</div>""", unsafe_allow_html=True)
        
        ans_box.markdown(f"""<div class='risk-card'>{full_answer}</div>""", unsafe_allow_html=True)
        
        # 4. BACKGROUND AUDIT (PARALLEL & FAST)
        with st.expander("🛡️ Technical Verification Audit", expanded=False):
            st.markdown("#### Factual Claim Audit")
            
            decomposed_claims = claims_engine.decompose_claims(full_answer)
            verifications = []
            
            # PARALLEL EXECUTION: The most effective way to speed up multiple LLM calls
            import concurrent.futures
            
            def process_claim(claim):
                # Local retriever call + shared engine call
                evidence_docs = retriever.invoke(claim)
                return verification_engine.verify_claim(claim, [d.page_content for d in evidence_docs])

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                # Map claims to the parallel processor
                future_to_claim = {executor.submit(process_claim, c): c for c in decomposed_claims}
                for i, future in enumerate(concurrent.futures.as_completed(future_to_claim)):
                    v = future.result()
                    verifications.append(v)
                    
                    # Status rendering
                    v_class = "supported" if v["verdict"] == "Supported" else "unsupported" if v["verdict"] == "Unsupported" else "partially"
                    st.markdown(f"**Assertion {i+1}:** {v['claim']}")
                    st.markdown(f"**Status:** <span class='{v_class}'>{v['verdict']}</span>", unsafe_allow_html=True)
                    st.write("---")
            
            scores = scoring_engine.calculate_scores(verifications, risk_meta['risk_level'])
            
            sc1, sc2 = st.columns(2)
            sc1.metric("Grounding Confidence", f"{scores['safety_percentage']}%")
            sc2.metric("Compliance Status", "AUTHENTICATED" if scores['safety_percentage'] >= st.session_state.risk_threshold else "FLAGGED")

            # Download Certificate
            report_data = {"timestamp": datetime.now().isoformat(), "query": query, "answer": full_answer, "grounding": scores['safety_percentage'], "verifications": verifications}
            st.download_button("Download Compliance Report", json.dumps(report_data, indent=4), file_name="audit_report.json", key=f"dl_{interaction_id}" if 'interaction_id' in locals() else None)

            # Adaptive Regen if below threshold
            if scores['safety_percentage'] < st.session_state.risk_threshold:
                st.error("Audit Violation: Grounding below threshold. Initiating Correction.")
                unsupported = [v['claim'] for v in verifications if v['verdict'] in ["Unsupported", "Partially Supported"]]
                with st.spinner("Refining response..."):
                    new_answer = regen_engine.regenerate(query, full_answer, unsupported, context)
                    st.markdown("#### Policy-Compliant Answer")
                    st.info(new_answer)
                    full_answer = new_answer
            
        # STEP 8: Log to Ledger
        interaction_id = ledger.log_interaction({
            "query": query,
            "category": risk_meta['category'],
            "risk_level": risk_meta['risk_level'],
            "answer": full_answer,
            "claims": decomposed_claims,
            "verifications": verifications,
            "grounding_score": scores['grounding_score'],
            "risk_score": scores['hallucination_risk'],
            "final_risk_class": scores['risk_class'],
            "department": dept
        })
        st.balloons()
        st.toast("Security Audit Complete & Logged", icon="🛡️")

        # FEEDBACK WIDGET
        st.divider()
        st.subheader("⭐ Influence the System")
        st.write("Your feedback directly improves AegisAI's future reasoning accuracy.")
        with st.form("feedback_form"):
            rating = st.slider("Rate the accuracy of this response", 1, 5, 5)
            comment = st.text_area("Suggest a correction or improvement (Optional)")
            if st.form_submit_button("Submit Feedback & Self-Develop"):
                ledger.add_feedback(interaction_id, rating, comment)
                st.success("AegisAI has updated its memory with your feedback. Future responses will learn from this.")

elif app_mode == "Governance Policy Center":
    render_header("data/orchestrator_icon.svg", "Governance Policy Center", size=50) # Reusing icon
    st.write("Tune organizational safety thresholds and AI guardrail strictness in real-time.")
    
    st.divider()
    
    st.subheader("🛡️ Safety Thresholds")
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Minimum Grounding Score (%)**")
        st.session_state.risk_threshold = st.slider(
            "Minimum certainty required to approve an AI answer.",
            min_value=0, max_value=100,
            value=int(st.session_state.risk_threshold),
            help="If grounding is below this, AegisAI will force a regeneration."
        )
        
    with col2:
        st.write("**Risk Sensitivity Multiplier**")
        sensitivity = st.select_slider(
            "Impact of high-risk categories (Legal/Finance) on scoring.",
            options=["Low", "Medium", "High", "Critical"]
        )
    
    st.divider()
    
    st.subheader("🤖 Model Control & Enforcement")
    st.toggle("Force Adaptive Regeneration", value=True, help="Automatically rewrite answers that fail grounding tests.")
    st.toggle("Enable Claim-by-Claim Verification", value=True)
    st.toggle("Microservice Authentication Required", value=True)
    
    if st.button("🔥 Factory Reset Policy"):
        st.session_state.risk_threshold = int(config.RISK_THRESHOLD * 100) if config.RISK_THRESHOLD <= 1.0 else int(config.RISK_THRESHOLD)
        st.success("Governance policy reset to organizational defaults.")
        st.rerun()

elif app_mode == "User Feedback Loop":
    render_header("data/pipeline_icon.svg", "Advanced Self-Improvement Loop", size=50)
    st.write("AegisAI uses **Retrieval-Augmented Few-Shot Learning** to develop itself from human oversight.")
    
    successes = ledger.get_highly_rated()
    if successes:
        st.subheader("🧠 Learned 'Golden' Behaviors")
        st.info("The system is currently injecting the following verified interactions into its reasoning engine:")
        for s in successes:
            with st.expander(f"Verified Fact: {s.query[:50]}..."):
                st.write(f"**Query:** {s.query}")
                st.write(f"**Verified Answer:** {s.answer}")
                st.write(f"**User Rating:** {s.user_rating}/5")
                if s.user_feedback:
                    st.caption(f"Reasoning Note: {s.user_feedback}")
    else:
        st.info("No 'Golden' interactions found yet. Provide feedback in the Orchestrator to start the learning loop.")

    st.divider()
    st.subheader("📋 Pending Reviews")
    logs = ledger.get_logs(limit=20)
    for l in logs:
        if not l.user_rating:
             with st.expander(f"Review Interaction: {l.timestamp.strftime('%H:%M')} | {l.query[:40]}..."):
                st.write(f"**Query:** {l.query}")
                st.write(f"**Answer:** {l.answer}")
                with st.form(f"feedback_loop_{l.id}"):
                    r = st.slider("Rating", 1, 5, 5, key=f"r_{l.id}")
                    c = st.text_area("Correction", key=f"c_{l.id}")
                    if st.form_submit_button("Authenticate & Feed System"):
                        ledger.add_feedback(l.id, r, c)
                        st.rerun()

elif app_mode == "Dashboard & Analytics":
    render_header("data/dashboard_icon.svg", "Enterprise AI Risk Dashboard", size=60)
    
    with st.expander("ℹ️ About the AegisAI Shield", expanded=False):
        st.write("""
        AegisAI is an **AI Governance Control Plane** designed to protect your organization from LLM hallucinations and compliance risks. 
        It operates across 10 distinct stages to verify every claim made by an AI model against your internal knowledge base.
        """)

    logs = ledger.get_logs(limit=100)
    if not logs:
        st.info("👋 **Welcome to AegisAI!** To see data here, go to the 'Risk Orchestrator' and run your first query.")
    else:
        # (Keep existing dashboard logic but maybe add some context)
        df = pd.DataFrame([
            {
                "Time": l.timestamp,
                "Category": l.category,
                "Risk Class": l.final_risk_class,
                "Grounding": l.grounding_score,
                "Risk Score": l.risk_score,
                "Dept": l.department
            } for l in logs
        ])
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Verifications", len(df), help="Total number of AI interactions processed through the Aegis pipeline.")
        with col2:
            avg_grounding = df["Grounding"].mean() * 100
            st.metric("Avg Grounding", f"{avg_grounding:.1f}%", help="Percentage of AI claims that are directly supported by your documents.")
        with col3:
            high_risk_pct = (len(df[df["Risk Class"].isin(["High Risk", "Critical"])]) / len(df)) * 100
            st.metric("Risk Exposure", f"{high_risk_pct:.1f}%", help="Percentage of responses flagged as High Risk or Critical.")
        with col4:
            budget_status, rate = budget_engine.check_budget(dept, logs)
            status_text = "Safe" if budget_status else "EXCEEDED"
            st.metric(f"{dept} Budget", status_text, f"{rate*100:.1f}% risk", help="Current risk consumption vs. department policy.")

        st.divider()
        c1, c2 = st.columns(2)
        with c1:
            st.subheader("Factual Integrity Trend")
            fig = px.area(df, x="Time", y="Risk Score", color="Dept", template="plotly_white",
                          title="Hallucination Risk Metrics", color_discrete_sequence=["#1e293b", "#475569", "#94a3b8"])
            st.plotly_chart(fig, use_container_width=True)
            
        with c2:
            st.subheader("Risk Distribution")
            fig_pie = px.pie(df, names="Risk Class", hole=0.6, template="plotly_white",
                             color_discrete_map={"Low Risk": "#059669", "Medium Risk": "#d97706", "High Risk": "#dc2626", "Critical": "#7f1d1d"})
            st.plotly_chart(fig_pie, use_container_width=True)

# --- NAVIGATION: Audit Ledger ---
elif app_mode == "Audit Ledger":
    render_header("data/ledger_icon.svg", "Corporate Audit Trail", size=50)
    st.write("Every interaction is cryptographically recorded for compliance and model drift analysis.")
    
    logs = ledger.get_logs(limit=50)
    if logs:
        # Display logs in a searchable, clean table or list
        for l in logs:
            with st.expander(f"🕒 {l.timestamp.strftime('%H:%M:%S')} | {l.department} | {l.query[:40]}..."):
                st.write(f"**Query:** {l.query}")
                st.write(f"**Risk Profile:** {l.category} / {l.final_risk_class}")
                st.divider()
                st.write("**Verified Response:**")
                st.write(l.answer)
    else:
        st.info("No audit logs available.")

# Footer
st.divider()
st.caption("AegisAI Enterprise Control Plane | Version 1.0.0 | Powered by Ollama & LangChain")