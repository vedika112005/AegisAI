class ScoringEngine:
    def calculate_scores(self, verifications, query_sensitivity="Low"):
        total = len(verifications)
        if total == 0:
            return {"grounding_score": 0, "hallucination_risk": 0, "risk_class": "Critical"}

        supported = len([v for v in verifications if v["verdict"] == "Supported"])
        partially = len([v for v in verifications if v["verdict"] == "Partially Supported"])
        
        # Grounding Score
        grounding_score = (supported + (0.5 * partially)) / total
        
        # Hallucination Risk Score
        # Higher score = higher risk
        avg_sim = sum([v["max_similarity"] for v in verifications]) / total
        disagreement_rate = len([v for v in verifications if v["entailment"] != v["critique"]]) / total
        
        hallucination_risk = (1 - grounding_score) * 0.6 + (1 - avg_sim) * 0.3 + disagreement_rate * 0.1
        
        if query_sensitivity == "High" or query_sensitivity == "Critical":
            hallucination_risk *= 1.2 # Weighting for sensitive queries
            
        # Risk Classification
        # Using the user's inverse logic for simplicity: 
        # 90-100% (Safety) -> Low Risk
        # 70-89% -> Medium
        # 50-69% -> High
        # < 50% -> Critical
        
        safety_percentage = grounding_score * 100
        
        if safety_percentage >= 90:
            risk_class = "Low Risk"
        elif safety_percentage >= 70:
            risk_class = "Medium Risk"
        elif safety_percentage >= 50:
            risk_class = "High Risk"
        else:
            risk_class = "Critical"
            
        return {
            "grounding_score": round(grounding_score, 2),
            "hallucination_risk": round(hallucination_risk, 2),
            "risk_class": risk_class,
            "safety_percentage": round(safety_percentage, 2)
        }
