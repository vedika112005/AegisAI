import json
from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq
from core.config import config

class RiskClassifier:
    def __init__(self, model_name="llama3"):
        if config.CLOUD_DEPLOYMENT and config.GROQ_API_KEY:
            self.llm = ChatGroq(groq_api_key=config.GROQ_API_KEY, model_name="llama3-70b-8192")
        else:
            self.llm = OllamaLLM(model=model_name)

    def classify_query(self, query: str):
        prompt = f"""
        Classify the following user query for an enterprise AI system.
        Categories: Legal, Financial, Healthcare, Compliance, HR, Informational.
        Risk Levels: Low, Medium, High, Critical.

        Return ONLY a JSON object with keys: "category" and "risk_level".

        Query: {query}
        """
        response = self.llm.invoke(prompt)
        try:
            # Simple cleanup in case LLM adds markdown or text
            json_str = response.strip()
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0].strip()
            elif "```" in json_str:
                 json_str = json_str.split("```")[1].split("```")[0].strip()
            
            return json.loads(json_str)
        except Exception as e:
            return {"category": "Informational", "risk_level": "Low"}
