from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq
from core.config import config

class RegenerationEngine:
    def __init__(self, model_name="llama3"):
        if config.CLOUD_DEPLOYMENT and config.GROQ_API_KEY:
            self.llm = ChatGroq(groq_api_key=config.GROQ_API_KEY, model_name="llama3-70b-8192")
        else:
            self.llm = OllamaLLM(model=model_name)

    def regenerate(self, query, original_answer, unsupported_claims, context):
        claims_str = "\n".join([f"- {c}" for c in unsupported_claims])
        
        prompt = f"""
        The previous answer contained some unsupported or inaccurate claims.
        Please regenerate the answer to the query, ensuring every statement is strictly backed by the provided context.
        
        Unsupported Claims to Fix:
        {claims_str}

        Original Answer:
        {original_answer}

        Context:
        {context}

        Question:
        {query}
        
        New Response (Strictly Evidence-Based):
        """
        return self.llm.invoke(prompt)
