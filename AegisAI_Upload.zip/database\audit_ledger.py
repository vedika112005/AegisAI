import json
import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Interaction(Base):
    __tablename__ = 'interactions'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    query = Column(Text)
    category = Column(String)
    risk_level = Column(String)
    answer = Column(Text)
    claims = Column(Text) # JSON string
    verifications = Column(Text) # JSON string
    grounding_score = Column(Float)
    risk_score = Column(Float)
    final_risk_class = Column(String)
    department = Column(String, default="General")
    user_rating = Column(Integer, nullable=True) # 1-5 Scale
    user_feedback = Column(Text, nullable=True)

class AuditLedger:
    def __init__(self, db_url="sqlite:///database/audit.db"):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def log_interaction(self, data):
        session = self.Session()
        interaction = Interaction(
            query=data['query'],
            category=data['category'],
            risk_level=data['risk_level'],
            answer=data['answer'],
            claims=json.dumps(data['claims']),
            verifications=json.dumps(data['verifications']),
            grounding_score=data['grounding_score'],
            risk_score=data['risk_score'],
            final_risk_class=data['final_risk_class'],
            department=data.get('department', 'General')
        )
        session.add(interaction)
        session.commit()
        last_id = interaction.id
        session.close()
        return last_id

    def add_feedback(self, interaction_id, rating, comment):
        session = self.Session()
        interaction = session.query(Interaction).filter_by(id=interaction_id).first()
        if interaction:
            interaction.user_rating = rating
            interaction.user_feedback = comment
            session.commit()
        session.close()

    def get_highly_rated(self, limit=5):
        """Returns interactions with high ratings to use for learning."""
        session = self.Session()
        results = session.query(Interaction).filter(Interaction.user_rating >= 4).limit(limit).all()
        session.close()
        return results

    def get_logs(self, limit=100):
        session = self.Session()
        logs = session.query(Interaction).order_by(Interaction.timestamp.desc()).limit(limit).all()
        session.close()
        return logs
