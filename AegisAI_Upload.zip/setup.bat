@echo off
echo ==============================================
echo 🚀 AegisAI Local Setup Script (Windows)
echo ==============================================

echo [1/5] Checking Python virtual environment...
if not exist "venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv venv
) else (
    echo Virtual environment already exists.
)

echo.
echo [2/5] Installing project dependencies...
call venv\Scripts\activate.bat
pip install -r requirements.txt
pip install -r requirements-dev.txt

echo.
echo [3/5] Setting up environment variables...
if not exist ".env" (
    echo Copying .env.example to .env...
    copy .env.example .env
) else (
    echo .env file already exists.
)

echo.
echo [4/5] Running Database Migrations (if applicable)...
python migrate_db.py

echo.
echo [5/5] Setup Complete!
echo You can now start the Streamlit application using:
echo run_app.bat
pause
