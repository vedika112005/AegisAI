import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from langchain_ollama import OllamaLLM
from langchain_groq import ChatGroq
from core.config import config

class VerificationEngine:
    def __init__(self, embedding_model, model_name="llama3"):
        self.embedding_model = embedding_model
        if config.CLOUD_DEPLOYMENT and config.GROQ_API_KEY:
            self.llm = ChatGroq(groq_api_key=config.GROQ_API_KEY, model_name="llama3-70b-8192")
        else:
            self.llm = OllamaLLM(model=model_name)

    def verify_claim(self, claim, evidence_chunks):
        # 1. Semantic Similarity (Batched embeddings for speed)
        claim_emb = np.array(self.embedding_model.embed_query(claim))
        chunk_embs = np.array(self.embedding_model.embed_documents(evidence_chunks))
        
        # Vectorized similarity Calculation (MUCH faster)
        dot_products = np.dot(chunk_embs, claim_emb)
        norms = np.linalg.norm(chunk_embs, axis=1) * np.linalg.norm(claim_emb)
        similarities = dot_products / norms
        
        best_idx = np.argmax(similarities)
        max_sim = similarities[best_idx]
        best_chunk = evidence_chunks[best_idx]
        
        # 2. Combined Logic & Critique (Single LLM Call for speed)
        # Using a direct prompt to avoid multiple round-trips
        verification_prompt = f"""
        Analyze the relationship between the CLAIM and the provided EVIDENCE.
        1. Does the evidence LOGICALLY ENTAIL the claim? (YES or NO)
        2. Is the claim FREE FROM HALLUCINATION? (YES or NO)
        
        CLAIM: {claim}
        EVIDENCE: {best_chunk}
        
        Respond with exactly: ENTAILS:[YES/NO], VALID:[YES/NO]
        """
        resp = self.llm.invoke(verification_prompt).strip().upper()
        
        # Fast parsing
        entails = "ENTAILS:YES" in resp
        critique_valid = "VALID:YES" in resp

        # Hybrid Decision Logic (Optimized for performance)
        if max_sim >= 0.85 and (entails or critique_valid):
            verdict = "Supported"
        elif entails and critique_valid:
            verdict = "Supported"
        elif max_sim >= 0.60 or entails or critique_valid:
            verdict = "Partially Supported"
        else:
            verdict = "Unsupported"

        return {
            "claim": claim,
            "max_similarity": float(max_sim),
            "entailment": entails,
            "critique": critique_valid,
            "verdict": verdict,
            "evidence": best_chunk[:400] + "..." if len(best_chunk) > 400 else best_chunk
        }

